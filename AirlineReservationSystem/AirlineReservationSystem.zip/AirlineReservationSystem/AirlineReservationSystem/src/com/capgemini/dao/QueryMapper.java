package com.capgemini.dao;


public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT FlightNo,AirLine,DepCity,ArrCity,DepDate,ArrDate,DepTime,ArrTime,FristSeat,FristSeatFare,BussSeat,BussSeatFare from FlightInformation";
	public static final String INSERT_QUERY="INSERT INTO BookingInformation VALUES(?,?,?,?,?,SeatNumberSeq.NEXTVAL,?,?,?)";
	public static final String SEATNO_QUERY_SEQUENCE="SELECT SeatNumberSeq.CURRVAL FROM DUAL";
	public static final String VIEW_BOOKING_DETAILS_QUERY="SELECT BookingId,CustEmail,NoOfPassengers,ClassType,TotalFare,CreditCardInfo,SrcCity,DestCity FROM BookingInformation WHERE  SeatNumber=?";
	//public static final String UPDATE_BOOKING_DETAILS_QUERY="update BookingInformation Set BookingId=?, CustEmail=?,NoOfPassengers=?, ClassType=?, TotalFare=?, CreditCardInfo=?, SrcCity=?, DestCity=?  WHERE SeatNumber=?";
	public static final String DELETE_BOOKING_DETAILS_QUERY="DELETE FROM BookingInformation WHERE SeatNumber=?";
	public static final String VIEW_FLIGHT_DETAILS_QUERY="SELECT AirLine,DepCity,ArrCity,DepDate,ArrDate,DepTime,ArrTime,FristSeat,FristSeatFare,BussSeat,BussSeatFare FROM FlightInformation WHERE  FlightNO=?";
}
