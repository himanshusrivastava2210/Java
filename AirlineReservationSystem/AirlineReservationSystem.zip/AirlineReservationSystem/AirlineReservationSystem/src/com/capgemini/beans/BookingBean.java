package com.capgemini.beans;


public class BookingBean {
	
	private String BookingId;
	private String CustEmail;
	private int NoOfPassengers;
	private String ClassType;
	private int Totalfare;
	private String SeatNumber;
	private String CreditCardInfo;
	private String SrcCity;
	private String DestCity;
	public String getBookingId() {
		return BookingId;
	}
	public void setBookingId(String bookingId) {
		BookingId = bookingId;
	}
	public String getCustEmail() {
		return CustEmail;
	}
	public void setCustEmail(String custEmail) {
		CustEmail = custEmail;
	}
	public int getNoOfPassengers() {
		return NoOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		NoOfPassengers = noOfPassengers;
	}
	public String getClassType() {
		return ClassType;
	}
	public void setClassType(String classType) {
		ClassType = classType;
	}
	public int getTotalfare() {
		return Totalfare;
	}
	public void setTotalfare(int totalfare) {
		Totalfare = totalfare;
	}
	public String getSeatNumber() {
		return SeatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		SeatNumber = seatNumber;
	}
	public String getCreditCardInfo() {
		return CreditCardInfo;
	}
	public void setCreditCardInfo(String creditCardInfo) {
		CreditCardInfo = creditCardInfo;
	}
	public String getSrcCity() {
		return SrcCity;
	}
	@Override
	public String toString() {
		return "BookingBean [BookingId=" + BookingId + ", CustEmail=" + CustEmail + ", NoOfPassengers=" + NoOfPassengers
				+ ", ClassType=" + ClassType + ", Totalfare=" + Totalfare + ", SeatNumber=" + SeatNumber
				+ ", CreditCardInfo=" + CreditCardInfo + ", SrcCity=" + SrcCity + ", DestCity=" + DestCity + "]";
	}
	public void setSrcCity(String srcCity) {
		SrcCity = srcCity;
	}
	public String getDestCity() {
		return DestCity;
	}
	public void setDestCity(String destCity) {
		DestCity = destCity;
	}


}
