package com.capgemini.exception;

public class AirLineException extends Exception 
{
	private static final long serialVersionUID = 726264577455921591L;

	public AirLineException(String message) 
	{
		
		super(message);
	}
}


