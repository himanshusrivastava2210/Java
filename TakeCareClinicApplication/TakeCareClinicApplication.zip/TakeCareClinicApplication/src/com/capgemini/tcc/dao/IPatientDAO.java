package com.capgemini.tcc.dao;
import java.util.List;

import ccom.capgemini.tcc.bean.*;

import com.capgemini.tcc.ui.*;
import com.capgemini.exception.*;
import com.capgemini.exception.*;
import com.capgemini.exception.PatientsException;

import ccom.capgemini.tcc.bean.Patientbean;
public interface IPatientDAO {
	public String addPatientDetails(Patientbean patientbean) throws PatientsException;
	public List<Patientbean> retriveAllDetails()throws PatientsException;
	public Patientbean viewPatientDetails(String patientId) throws PatientsException;
}





