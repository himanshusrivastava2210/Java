package com.igate.contactbook.bean;

public class EnquiryBean {

	private int enqryid;
	private String fName;
	private String lName;
	private String contactNo;
	private String pLocation;
	private String pDomain;
	
	
	//Getters  And Setters of the Following Fields
	
	public int getEnqryid() {
		return enqryid;
	}
	public void setEnqryid(int enqryid) {
		this.enqryid = enqryid;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getpLocation() {
		return pLocation;
	}
	public void setpLocation(String pLocation) {
		this.pLocation = pLocation;
	}
	public String getpDomain() {
		return pDomain;
	}
	public void setpDomain(String pDomain) {
		this.pDomain = pDomain;
	}
	
}
