/*package com.capgemini.contactbook.dao;

public class QueryMapper {
	
	//public static final String RETRIVE_ALL_QUERY="SELECT donor_name,address,phone_number,donor_date,donor_amount FROM donor_details";
	public static final String VIEW_ENQUIRY_DETAILS_ON_IDQUERY="SELECT enqryId,firstName,lastName,contactNo,domain,city FROM enquiry WHERE  enqryId=?";
	public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enqryId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enqryId_sequence.CURRVAL FROM DUAL";
}
*/